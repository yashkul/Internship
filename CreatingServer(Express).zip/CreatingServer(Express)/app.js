const express = require('express');

const app = express();

app.get('/', function(req,res){
    res.send('WELCOME HOME')
})

app.get('/about', function(req,res){
    res.send('This is a About Page')
})

app.listen(9000, function(req,res){
    console.log('Running...')
});